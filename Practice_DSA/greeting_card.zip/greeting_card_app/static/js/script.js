document.addEventListener('DOMContentLoaded', function() {
    // Card form preview functionality
    const themeRadios = document.querySelectorAll('input[name="background"]');
    const colorSchemeRadios = document.querySelectorAll('input[name="color_scheme"]');
    const fontRadios = document.querySelectorAll('input[name="font"]');
    
    // Add smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
    
    // Add animation when cards appear in viewport
    const animateOnScroll = () => {
        const cards = document.querySelectorAll('.feature-card, .occasion-card, .saved-card-item');
        cards.forEach(card => {
            const cardPosition = card.getBoundingClientRect().top;
            const screenPosition = window.innerHeight / 1.3;
            
            if (cardPosition < screenPosition) {
                card.classList.add('animate__animated', 'animate__fadeInUp');
            }
        });
    };
    
    window.addEventListener('scroll', animateOnScroll);
    animateOnScroll(); // Initial check on page load
    
    // Form validation enhancement
    const form = document.querySelector('form');
    if (form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
                
                // Highlight the first invalid field
                const invalidFields = form.querySelectorAll(':invalid');
                if (invalidFields.length > 0) {
                    invalidFields[0].focus();
                }
            }
            
            form.classList.add('was-validated');
        });
    }
    
    // Lazy load card background images
    function loadCardBackgrounds() {
        const miniCards = document.querySelectorAll('.mini-card.card-loading');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const card = entry.target;
                    const bgUrl = card.getAttribute('data-bg-url');
                    
                    // Pre-load the image
                    const img = new Image();
                    img.onload = function() {
                        card.style.backgroundImage = `url('${bgUrl}')`;
                        card.classList.remove('card-loading');
                        card.setAttribute('data-loaded', 'true');
                    };
                    
                    img.onerror = function() {
                        // Use fallback gradient background if image fails to load
                        card.style.backgroundImage = 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)';
                        card.classList.remove('card-loading');
                        card.classList.add('card-load-error');
                        console.error(`Failed to load image: ${bgUrl}`);
                    };
                    
                    // Add timeout for slow connections
                    setTimeout(() => {
                        if (!card.hasAttribute('data-loaded')) {
                            img.src = bgUrl;
                        }
                    }, 100);
                    
                    img.src = bgUrl;
                    observer.unobserve(card);
                }
            });
        }, {
            rootMargin: '100px'
        });
        
        miniCards.forEach(card => {
            observer.observe(card);
        });
    }
    
    // Handle card downloads
    function setupCardDownloads() {
        const downloadLinks = document.querySelectorAll('a[href^="/download/"]');
        
        downloadLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                const cardId = this.getAttribute('href').split('/').pop();
                const cardElement = document.querySelector(`.greeting-card, .mini-card[data-card-id="${cardId}"]`);
                
                // Show download in progress notification
                const notification = createNotification('Preparing your card for download...', 'info');
                
                // Make AJAX request to get card data
                fetch(`/card-data/${cardId}`)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Could not retrieve card data');
                        }
                        return response.json();
                    })
                    .then(cardData => {
                        // Generate card image using canvas
                        generateCardImage(cardData, function(dataUrl) {
                            // Create temporary download link
                            const downloadLink = document.createElement('a');
                            downloadLink.href = dataUrl;
                            downloadLink.download = `greeting-card-${cardId.substring(0, 8)}.png`;
                            document.body.appendChild(downloadLink);
                            
                            // Trigger download and cleanup
                            downloadLink.click();
                            document.body.removeChild(downloadLink);
                            
                            // Update notification
                            updateNotification(notification, 'Card downloaded successfully!', 'success');
                            
                            // Automatically remove notification after 3 seconds
                            setTimeout(() => {
                                removeNotification(notification);
                            }, 3000);
                        });
                    })
                    .catch(error => {
                        console.error('Download error:', error);
                        updateNotification(notification, 'Sorry, download failed. Please try again.', 'error');
                        
                        // Fallback to server-side download method
                        window.location.href = this.href;
                    });
            });
        });
    }
    
    // Helper functions for notification system
    function createNotification(message, type) {
        const notificationArea = document.getElementById('notification-area') || createNotificationArea();
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas ${getIconForType(type)} me-2"></i>
                <span>${message}</span>
            </div>
            <button type="button" class="btn-close" aria-label="Close"></button>
        `;
        
        notification.querySelector('.btn-close').addEventListener('click', () => {
            removeNotification(notification);
        });
        
        notificationArea.appendChild(notification);
        return notification;
    }
    
    function updateNotification(notification, message, type) {
        notification.className = `notification notification-${type}`;
        notification.querySelector('i').className = `fas ${getIconForType(type)} me-2`;
        notification.querySelector('span').textContent = message;
    }
    
    function removeNotification(notification) {
        notification.classList.add('notification-hiding');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }
    
    function createNotificationArea() {
        const area = document.createElement('div');
        area.id = 'notification-area';
        document.body.appendChild(area);
        return area;
    }
    
    function getIconForType(type) {
        switch(type) {
            case 'success': return 'fa-check-circle';
            case 'error': return 'fa-exclamation-circle';
            case 'info': return 'fa-info-circle';
            default: return 'fa-info-circle';
        }
    }
    
    // Generate greeting card as image using canvas
    function generateCardImage(cardData, callback) {
        const canvas = document.createElement('canvas');
        canvas.width = 800;
        canvas.height = 600;
        const ctx = canvas.getContext('2d');
        
        // Load background image
        const bgImg = new Image();
        bgImg.crossOrigin = 'anonymous'; // Enable CORS for the image
        
        bgImg.onload = function() {
            // Draw background
            ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);
            
            // Add semi-transparent overlay
            ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            // Set text styles based on card data
            setupCanvasTextStyles(ctx, cardData.font, cardData.color_scheme);
            
            // Draw recipient
            ctx.textAlign = 'center';
            ctx.font = '28px ' + getFontFamily(cardData.font);
            ctx.fillText(`Dear ${cardData.recipient},`, canvas.width/2, 150);
            
            // Draw message (with word wrap)
            ctx.font = '22px ' + getFontFamily(cardData.font);
            wrapText(ctx, cardData.message, canvas.width/2, 250, canvas.width - 200, 30);
            
            // Draw sender
            ctx.font = '24px ' + getFontFamily(cardData.font);
            ctx.fillText(`With love,`, canvas.width/2, 500);
            ctx.fillText(`${cardData.sender}`, canvas.width/2, 540);
            
            // Convert to data URL and send to callback
            const dataUrl = canvas.toDataURL('image/png');
            callback(dataUrl);
        };
        
        bgImg.onerror = function() {
            // On error, draw a gradient background
            const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
            gradient.addColorStop(0, "#f5f7fa");
            gradient.addColorStop(1, "#c3cfe2");
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            // Still draw the text
            setupCanvasTextStyles(ctx, cardData.font, cardData.color_scheme);
            
            ctx.textAlign = 'center';
            ctx.font = '28px ' + getFontFamily(cardData.font);
            ctx.fillText(`Dear ${cardData.recipient},`, canvas.width/2, 150);
            
            ctx.font = '22px ' + getFontFamily(cardData.font);
            wrapText(ctx, cardData.message, canvas.width/2, 250, canvas.width - 200, 30);
            
            ctx.font = '24px ' + getFontFamily(cardData.font);
            ctx.fillText(`With love,`, canvas.width/2, 500);
            ctx.fillText(`${cardData.sender}`, canvas.width/2, 540);
            
            const dataUrl = canvas.toDataURL('image/png');
            callback(dataUrl);
        };
        
        bgImg.src = `/static/images/backgrounds/${cardData.background}.jpg`;
    }
    
    function getFontFamily(fontType) {
        switch(fontType) {
            case 'elegant': return '"Times New Roman", serif';
            case 'playful': return '"Pacifico", cursive';
            case 'bold': return '"Arial Black", sans-serif';
            default: return '"Montserrat", sans-serif';
        }
    }
    
    function setupCanvasTextStyles(ctx, fontType, colorScheme) {
        // Set text color based on color scheme
        const colorMap = {
            'pastel': '#355C7D',
            'vibrant': '#F85931',
            'elegant': '#4C5C68',
            'cheerful': '#2D3436',
            'serene': '#388087'
        };
        
        ctx.fillStyle = colorMap[colorScheme] || '#333333';
    }
    
    function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
        const words = text.split(' ');
        let line = '';
        
        for(let n = 0; n < words.length; n++) {
            const testLine = line + words[n] + ' ';
            const metrics = ctx.measureText(testLine);
            const testWidth = metrics.width;
            
            if (testWidth > maxWidth && n > 0) {
                ctx.fillText(line, x, y);
                line = words[n] + ' ';
                y += lineHeight;
            } else {
                line = testLine;
            }
        }
        
        ctx.fillText(line, x, y);
    }
    
    // Initialize lazy loading if cards are present
    if (document.querySelector('.mini-card')) {
        loadCardBackgrounds();
    }
    
    // Initialize download functionality
    document.addEventListener('DOMContentLoaded', function() {
        setupCardDownloads();
    });
    
    // Add a global event listener for background selection changes
    document.querySelectorAll('input[name="background"]').forEach(input => {
        input.addEventListener('change', function() {
            console.log('Background changed to:', this.value);
            
            // If gradient-generator.js is loaded and updateCardPreview function exists
            if (typeof updateCardPreview === 'function') {
                updateCardPreview();
            } else {
                console.log('updateCardPreview function not found');
                // Fallback basic implementation
                const cardPreview = document.getElementById('card-preview');
                if (cardPreview) {
                    if (this.value.startsWith('gradient-')) {
                        // Find the gradient card and copy its style
                        const gradientCard = document.querySelector(`.gradient-theme-card[data-gradient-id="${this.value}"]`);
                        if (gradientCard) {
                            cardPreview.style.backgroundImage = gradientCard.style.backgroundImage;
                        }
                    } else if (this.value !== 'custom-gradient' && this.value !== 'custom-image') {
                        // Standard background
                        const imgSrc = document.querySelector(`#bg-${this.value} + label img`)?.src;
                        if (imgSrc) {
                            cardPreview.style.backgroundImage = `url('${imgSrc}')`;
                        }
                    }
                }
            }
        });
    });
});
