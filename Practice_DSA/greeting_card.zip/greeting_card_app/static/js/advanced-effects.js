/**
 * Advanced Effects for Greeting Card App
 * Provides real-time preview updates, animations, and advanced image processing
 */

// Execute when DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize advanced features
    initRealTimePreview();
    initImageEnhancements();
    initAdvancedTextEffects();
    initAnimationEffects();
    initColorAnalysis();
    
    // Add helper functions to global scope for other scripts
    window.updateCustomGradient = updateCustomGradient || function() {};
    window.updateCardPreview = updateCardPreview || function() {};
});

/**
 * Real-time preview updates as user types or changes settings
 */
function initRealTimePreview() {
    // Get form elements
    const formInputs = document.querySelectorAll('#cardForm input, #cardForm textarea, #cardForm select');
    const previewContainer = document.getElementById('card-preview-container');
    
    if (!previewContainer) return;
    
    // Update preview with debounce for better performance
    let updateTimer;
    const updatePreview = function() {
        clearTimeout(updateTimer);
        updateTimer = setTimeout(() => {
            const formData = new FormData(document.getElementById('cardForm'));
            
            // Show loading indicator
            previewContainer.classList.add('loading');
            
            // Create AbortController to handle timeout
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout
            
            // Send AJAX request to get updated preview
            fetch('/api/preview', {
                method: 'POST',
                body: formData,
                signal: controller.signal
            })
            .then(response => response.json())
            .then(data => {
                clearTimeout(timeoutId);
                if (data.previewHtml) {
                    // Update preview content
                    previewContainer.innerHTML = data.previewHtml;
                    
                    // Apply animations
                    animatePreview();
                }
            })
            .catch(error => {
                clearTimeout(timeoutId);
                console.error('Preview update error:', error);
                
                // Handle timeout specifically
                if (error.name === 'AbortError') {
                    console.log('Preview request timed out, using client-side fallback');
                    updateClientSidePreview(formData);
                }
            })
            .finally(() => {
                previewContainer.classList.remove('loading');
            });
        }, 300); // Debounce delay
    };
    
    // Listen to input changes
    formInputs.forEach(input => {
        input.addEventListener('input', updatePreview);
        input.addEventListener('change', updatePreview);
    });
    
    // Initial preview
    updatePreview();
}

/**
 * Fallback client-side preview update when server request times out
 */
function updateClientSidePreview(formData) {
    const previewContainer = document.getElementById('card-preview-container');
    if (!previewContainer) return;
    
    // Extract basic info from form
    const recipient = formData.get('recipient') || 'Friend';
    const sender = formData.get('sender') || 'Me';
    const message = formData.get('message') || 'Your message here...';
    const font = formData.get('font') || 'default';
    
    // Create basic preview HTML
    const previewHtml = `
        <div class="greeting-card animate-fade-in">
            <div class="greeting-card-inner">
                <div class="greeting-content font-${font}">
                    <div class="recipient">Dear ${recipient},</div>
                    <div class="message">${message}</div>
                    <div class="sender">With love,<br>${sender}</div>
                </div>
            </div>
        </div>
        <div class="text-center mt-2 text-muted">
            <small>* Preview generated client-side (server unavailable)</small>
        </div>
    `;
    
    previewContainer.innerHTML = previewHtml;
}

/**
 * Advanced image enhancement tools
 */
function initImageEnhancements() {
    const imageUpload = document.getElementById('custom-image-upload');
    const enhancementControls = document.getElementById('image-enhancement-controls');
    
    if (!imageUpload || !enhancementControls) return;
    
    // Show enhancement controls when image is uploaded
    imageUpload.addEventListener('change', function(e) {
        if (this.files && this.files[0]) {
            enhancementControls.classList.remove('d-none');
            
            // Create preview
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('enhancement-preview').src = e.target.result;
            };
            reader.readAsDataURL(this.files[0]);
        }
    });
    
    // Apply enhancements on slider change
    const enhancementSliders = document.querySelectorAll('.enhancement-slider');
    enhancementSliders.forEach(slider => {
        slider.addEventListener('input', applyImageEnhancements);
    });
}

/**
 * Apply image enhancements using server-side processing
 */
function applyImageEnhancements() {
    const imageUpload = document.getElementById('custom-image-upload');
    if (!imageUpload.files || !imageUpload.files[0]) return;
    
    // Get enhancement values
    const brightness = document.getElementById('brightness-slider').value;
    const contrast = document.getElementById('contrast-slider').value;
    const saturation = document.getElementById('saturation-slider').value;
    const sharpness = document.getElementById('sharpness-slider').value;
    
    // Prepare form data
    const formData = new FormData();
    formData.append('image', imageUpload.files[0]);
    formData.append('brightness', brightness);
    formData.append('contrast', contrast);
    formData.append('saturation', saturation);
    formData.append('sharpness', sharpness);
    
    // Show processing indicator
    document.getElementById('enhancement-preview-container').classList.add('processing');
    
    // Create AbortController for timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 second timeout
    
    // Send to server for processing
    fetch('/api/enhance-image', {
        method: 'POST',
        body: formData,
        signal: controller.signal
    })
    .then(response => response.json())
    .then(data => {
        clearTimeout(timeoutId);
        if (data.enhancedImage) {
            // Update preview with enhanced image
            document.getElementById('enhancement-preview').src = data.enhancedImage;
            
            // Store enhanced image data for submission
            document.getElementById('enhanced-image-data').value = data.enhancedImage;
        }
    })
    .catch(error => {
        clearTimeout(timeoutId);
        console.error('Image enhancement error:', error);
        
        // Handle timeout
        if (error.name === 'AbortError') {
            // Show timeout message
            const container = document.getElementById('enhancement-preview-container');
            container.innerHTML += '<div class="alert alert-warning mt-2">Processing timed out. Try a smaller image or lower quality settings.</div>';
        }
    })
    .finally(() => {
        document.getElementById('enhancement-preview-container').classList.remove('processing');
    });
}

/**
 * Advanced text effects for typography
 */
function initAdvancedTextEffects() {
    const textEffectControls = document.querySelectorAll('.text-effect-control');
    
    textEffectControls.forEach(control => {
        control.addEventListener('change', updateTextEffects);
    });
    
    // Initialize text effect preview
    updateTextEffects();
}

/**
 * Update text effects preview
 */
function updateTextEffects() {
    const previewText = document.querySelector('.greeting-content');
    if (!previewText) return;
    
    // Get effect settings
    const shadow = document.getElementById('text-shadow-toggle')?.checked || false;
    const glow = document.getElementById('text-glow-toggle')?.checked || false;
    const spacing = document.getElementById('letter-spacing-control')?.value || 0;
    
    // Apply effects to preview
    if (shadow) {
        previewText.style.textShadow = '2px 2px 4px rgba(0,0,0,0.3)';
    } else {
        previewText.style.textShadow = 'none';
    }
    
    if (glow) {
        previewText.style.textShadow = '0 0 10px rgba(255,255,255,0.8), 0 0 20px rgba(255,255,255,0.5)';
    }
    
    previewText.style.letterSpacing = `${spacing}px`;
    
    // Store settings for download
    document.getElementById('text-effects-data')?.value = JSON.stringify({
        shadow,
        glow,
        spacing
    });
}

/**
 * Card animation effects
 */
function initAnimationEffects() {
    // Apply entrance animation to preview card
    animatePreview();
    
    // Setup animation controls
    const animationSelect = document.getElementById('animation-effect');
    if (animationSelect) {
        animationSelect.addEventListener('change', function() {
            animatePreview(this.value);
        });
    }
}

/**
 * Animate the card preview with selected effect
 */
function animatePreview(effect = 'fade-in') {
    const card = document.querySelector('.greeting-card');
    if (!card) return;
    
    // Reset animations
    card.classList.remove('animate-fade-in', 'animate-slide-up', 'animate-zoom-in', 'animate-flip');
    
    // Force browser reflow
    void card.offsetWidth;
    
    // Apply new animation
    card.classList.add(`animate-${effect}`);
}

/**
 * AI-powered color analysis for uploaded images
 */
function initColorAnalysis() {
    const imageUpload = document.getElementById('custom-image-upload');
    const colorAnalysisBtn = document.getElementById('analyze-colors-btn');
    
    if (!imageUpload || !colorAnalysisBtn) return;
    
    colorAnalysisBtn.addEventListener('click', function() {
        if (!imageUpload.files || !imageUpload.files[0]) {
            alert('Please upload an image first');
            return;
        }
        
        // Show loading state
        this.disabled = true;
        this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Analyzing...';
        
        // Prepare image for analysis
        const formData = new FormData();
        formData.append('image', imageUpload.files[0]);
        
        // Send to server for color analysis
        fetch('/api/analyze-image-colors', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            // Display color palette and suggested schemes
            displayColorAnalysisResults(data);
        })
        .catch(error => console.error('Color analysis error:', error))
        .finally(() => {
            // Reset button
            this.disabled = false;
            this.innerHTML = '<i class="fas fa-magic"></i> Analyze Colors';
        });
    });
}

/**
 * Display color analysis results in the UI
 */
function displayColorAnalysisResults(data) {
    const resultsContainer = document.getElementById('color-analysis-results');
    if (!resultsContainer) return;
    
    // Show the container
    resultsContainer.classList.remove('d-none');
    
    // Clear previous results
    resultsContainer.innerHTML = '';
    
    // Create color palette section
    const paletteSection = document.createElement('div');
    paletteSection.className = 'mb-4';
    paletteSection.innerHTML = `<h5>Dominant Colors</h5>`;
    
    // Add color swatches
    const colorRow = document.createElement('div');
    colorRow.className = 'd-flex flex-wrap gap-2 mb-3';
    
    data.dominantColors.forEach(color => {
        const swatch = document.createElement('div');
        swatch.className = 'color-swatch-large';
        swatch.style.backgroundColor = color.hex;
        swatch.title = `${color.hex} (${color.percentage.toFixed(1)}%)`;
        swatch.setAttribute('data-hex', color.hex);
        swatch.addEventListener('click', () => applyColorToCard(color.hex));
        colorRow.appendChild(swatch);
    });
    
    paletteSection.appendChild(colorRow);
    resultsContainer.appendChild(paletteSection);
    
    // Add suggested schemes
    const schemesSection = document.createElement('div');
    schemesSection.innerHTML = `<h5>Suggested Color Schemes</h5>`;
    
    for (const [schemeName, colors] of Object.entries(data.suggestedSchemes)) {
        const schemeRow = document.createElement('div');
        schemeRow.className = 'mb-3';
        
        schemeRow.innerHTML = `
            <div class="d-flex align-items-center mb-1">
                <small class="text-muted text-capitalize">${schemeName}:</small>
                <button class="btn btn-sm btn-outline-primary ms-2 apply-scheme-btn">Apply</button>
            </div>
            <div class="d-flex flex-wrap gap-2"></div>
        `;
        
        const swatchContainer = schemeRow.querySelector('.d-flex.flex-wrap');
        
        colors.forEach(color => {
            const swatch = document.createElement('div');
            swatch.className = 'color-swatch-medium';
            swatch.style.backgroundColor = color;
            swatchContainer.appendChild(swatch);
        });
        
        // Add click handler for apply button
        schemeRow.querySelector('.apply-scheme-btn').addEventListener('click', () => {
            applyColorSchemeToCard(colors);
        });
        
        schemesSection.appendChild(schemeRow);
    }
    
    resultsContainer.appendChild(schemesSection);
}

/**
 * Apply a color to the card background
 */
function applyColorToCard(hexColor) {
    // Set custom gradient colors
    document.getElementById('custom-gradient-color1').value = hexColor;
    document.getElementById('custom-gradient-color2').value = lightenDarkenColor(hexColor, 40);
    
    // Select custom gradient option
    document.getElementById('bg-custom-gradient').checked = true;
    
    // Update preview
    updateCustomGradient();
    updateCardPreview();
}

/**
 * Apply a color scheme to the card
 */
function applyColorSchemeToCard(colors) {
    if (colors.length < 2) return;
    
    // Set custom gradient colors
    document.getElementById('custom-gradient-color1').value = colors[0];
    document.getElementById('custom-gradient-color2').value = colors[1];
    
    // Select custom gradient option
    document.getElementById('bg-custom-gradient').checked = true;
    
    // Update preview
    updateCustomGradient();
    updateCardPreview();
}

/**
 * Utility to lighten or darken a hex color
 */
function lightenDarkenColor(hex, amount) {
    let r = parseInt(hex.substring(1, 3), 16);
    let g = parseInt(hex.substring(3, 5), 16);
    let b = parseInt(hex.substring(5, 7), 16);
    
    r = Math.min(255, Math.max(0, r + amount));
    g = Math.min(255, Math.max(0, g + amount));
    b = Math.min(255, Math.max(0, b + amount));
    
    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
}

/**
 * Update custom gradient preview and hidden input
 */
function updateCustomGradient() {
    const colorPicker1 = document.getElementById('custom-gradient-color1');
    const colorPicker2 = document.getElementById('custom-gradient-color2');
    const gradientDirectionSelect = document.getElementById('gradient-direction');
    const customGradientPreview = document.getElementById('custom-gradient-preview');
    
    if (!colorPicker1 || !colorPicker2 || !customGradientPreview) return;
    
    const color1 = colorPicker1.value;
    const color2 = colorPicker2.value;
    const direction = gradientDirectionSelect ? gradientDirectionSelect.value : 'to right';
    
    const gradientString = `linear-gradient(${direction}, ${color1}, ${color2})`;
    customGradientPreview.style.backgroundImage = gradientString;
    
    // Update hidden input for submission
    const customGradientValue = document.getElementById('custom-gradient-value');
    if (customGradientValue) {
        customGradientValue.value = JSON.stringify({
            color1: color1,
            color2: color2,
            direction: direction
        });
    }
}

/**
 * Update card preview background based on selected options
 */
function updateCardPreview() {
    const cardPreview = document.querySelector('#card-preview, .greeting-card');
    if (!cardPreview) return;
    
    const selectedBackground = document.querySelector('input[name="background"]:checked');
    if (!selectedBackground) return;
    
    const bgValue = selectedBackground.value;
    
    if (bgValue === 'custom-gradient') {
        const color1 = document.getElementById('custom-gradient-color1')?.value || '#4e54c8';
        const color2 = document.getElementById('custom-gradient-color2')?.value || '#8f94fb';
        const direction = document.getElementById('gradient-direction')?.value || 'to right';
        
        cardPreview.style.backgroundImage = `linear-gradient(${direction}, ${color1}, ${color2})`;
    } 
    else if (bgValue === 'custom-image' && document.getElementById('custom-image-upload')?.files[0]) {
        const fileInput = document.getElementById('custom-image-upload');
        const file = fileInput.files[0];
        
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                cardPreview.style.backgroundImage = `url('${e.target.result}')`;
            };
            reader.readAsDataURL(file);
        }
    }
    else if (bgValue.startsWith('gradient-')) {
        const gradientCard = document.querySelector(`.gradient-theme-card[data-gradient-id="${bgValue}"]`);
        if (gradientCard && gradientCard.style.backgroundImage) {
            cardPreview.style.backgroundImage = gradientCard.style.backgroundImage;
        }
    }
    else {
        // Try to find the image element for this background
        const imgElement = document.querySelector(`#bg-${bgValue} + label img`);
        if (imgElement && imgElement.src) {
            cardPreview.style.backgroundImage = `url('${imgElement.src}')`;
        } else {
            // Fallback
            cardPreview.style.backgroundImage = `url('/static/images/backgrounds/${bgValue}.jpg')`;
        }
    }
}
