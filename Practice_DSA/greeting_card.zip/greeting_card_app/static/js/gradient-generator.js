/**
 * Gradient Background Generator
 * Handles gradient preview and custom color selection
 */
document.addEventListener('DOMContentLoaded', function() {
    // Setup gradient previews
    setupGradientPreviews();
    
    // Setup color pickers for custom gradients
    setupColorPickers();
    
    // Handle custom image upload preview
    setupImageUploadPreview();
    
    // Handle background blur/opacity controls
    setupBackgroundControls();
});

function setupGradientPreviews() {
    // Refresh all gradient previews
    const gradientCards = document.querySelectorAll('.gradient-theme-card');
    
    gradientCards.forEach(card => {
        const gradientType = card.dataset.gradientType;
        const color1 = card.dataset.color1;
        const color2 = card.dataset.color2;
        const direction = card.dataset.direction || 'to right bottom';
        
        const gradientString = `linear-gradient(${direction}, ${color1}, ${color2})`;
        card.style.backgroundImage = gradientString;
    });
    
    // Apply selected gradient to the preview
    document.querySelectorAll('input[name="background"]').forEach(input => {
        input.addEventListener('change', function() {
            if (this.value.startsWith('gradient-')) {
                updateCardPreview();
            }
        });
    });
}

function setupColorPickers() {
    const colorPicker1 = document.getElementById('custom-gradient-color1');
    const colorPicker2 = document.getElementById('custom-gradient-color2');
    const gradientDirectionSelect = document.getElementById('gradient-direction');
    const customGradientPreview = document.getElementById('custom-gradient-preview');
    
    if (!colorPicker1 || !colorPicker2) return;
    
    function updateCustomGradient() {
        const color1 = colorPicker1.value;
        const color2 = colorPicker2.value;
        const direction = gradientDirectionSelect.value;
        
        const gradientString = `linear-gradient(${direction}, ${color1}, ${color2})`;
        customGradientPreview.style.backgroundImage = gradientString;
        
        // Update hidden input for submission - THIS IS IMPORTANT
        const customGradientValue = document.getElementById('custom-gradient-value');
        if (customGradientValue) {
            customGradientValue.value = JSON.stringify({
                color1: color1,
                color2: color2,
                direction: direction
            });
            console.log("Updated custom gradient value:", customGradientValue.value);
        }
            
        // Update card preview if custom gradient is selected
        if (document.getElementById('bg-custom-gradient') && document.getElementById('bg-custom-gradient').checked) {
            updateCardPreview();
        }
    }
    
    // Call updateCustomGradient immediately to ensure form field is populated
    updateCustomGradient();
    
    colorPicker1.addEventListener('input', updateCustomGradient);
    colorPicker2.addEventListener('input', updateCustomGradient);
    gradientDirectionSelect.addEventListener('change', updateCustomGradient);
}

function setupImageUploadPreview() {
    const imageUpload = document.getElementById('custom-image-upload');
    const imagePreview = document.getElementById('custom-image-preview');
    
    if (!imageUpload || !imagePreview) return;
    
    imageUpload.addEventListener('change', function(e) {
        if (this.files && this.files[0]) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                imagePreview.style.backgroundImage = `url('${e.target.result}')`;
                imagePreview.style.backgroundSize = 'cover';
                imagePreview.style.backgroundPosition = 'center';
                
                // Auto-select the custom image option
                document.getElementById('bg-custom-image').checked = true;
                
                // Update card preview
                updateCardPreview();
            };
            
            reader.readAsDataURL(this.files[0]);
        }
    });
}

function setupBackgroundControls() {
    const blurControl = document.getElementById('background-blur');
    const opacityControl = document.getElementById('background-opacity');
    
    if (!blurControl || !opacityControl) return;
    
    const updateBackgroundEffect = function() {
        const blurValue = blurControl.value;
        const opacityValue = opacityControl.value;
        
        document.getElementById('blur-value-display').textContent = blurValue;
        document.getElementById('opacity-value-display').textContent = opacityValue;
        
        document.getElementById('card-preview-overlay').style.backdropFilter = `blur(${blurValue}px)`;
        document.getElementById('card-preview-overlay').style.backgroundColor = 
            `rgba(255, 255, 255, ${opacityValue/100})`;
    };
    
    blurControl.addEventListener('input', updateBackgroundEffect);
    opacityControl.addEventListener('input', updateBackgroundEffect);
    
    // Initialize
    updateBackgroundEffect();
}

function updateCardPreview() {
    const selectedBackground = document.querySelector('input[name="background"]:checked').value;
    const cardPreview = document.getElementById('card-preview');
    
    if (!cardPreview) return;
    
    if (selectedBackground === 'custom-gradient') {
        const color1 = document.getElementById('custom-gradient-color1').value;
        const color2 = document.getElementById('custom-gradient-color2').value;
        const direction = document.getElementById('gradient-direction').value;
        
        cardPreview.style.backgroundImage = `linear-gradient(${direction}, ${color1}, ${color2})`;
    } 
    else if (selectedBackground === 'custom-image' && document.getElementById('custom-image-upload').files[0]) {
        // Use the custom image preview's background
        cardPreview.style.backgroundImage = document.getElementById('custom-image-preview').style.backgroundImage;
    }
    else if (selectedBackground.startsWith('gradient-')) {
        const gradientCard = document.querySelector(`.gradient-theme-card[data-gradient-id="${selectedBackground}"]`);
        if (gradientCard) {
            cardPreview.style.backgroundImage = gradientCard.style.backgroundImage;
        }
    }
    else {
        // Standard background image - Add error handling for missing images
        try {
            const imgElement = document.querySelector(`#bg-${selectedBackground} + label img`);
            
            if (imgElement) {
                // Check if image exists before setting it as background
                const img = new Image();
                img.onload = function() {
                    cardPreview.style.backgroundImage = `url('${imgElement.src}')`;
                };
                
                img.onerror = function() {
                    console.error(`Background image not found: ${imgElement.src}`);
                    // Use a fallback gradient if image is missing
                    cardPreview.style.backgroundImage = 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)';
                    // Show a warning to the user
                    const alertDiv = document.createElement('div');
                    alertDiv.className = 'alert alert-warning mt-2 image-error-alert';
                    alertDiv.innerHTML = `<i class="fas fa-exclamation-triangle me-2"></i> 
                                        Background image could not be loaded. Using a fallback gradient.`;
                    
                    // Remove any existing alerts
                    document.querySelectorAll('.image-error-alert').forEach(el => el.remove());
                    
                    // Add alert after preview
                    cardPreview.parentNode.insertBefore(alertDiv, cardPreview.nextSibling);
                    
                    // Auto-dismiss the alert after 5 seconds
                    setTimeout(() => {
                        if (alertDiv.parentNode) {
                            alertDiv.classList.add('fade');
                            setTimeout(() => alertDiv.remove(), 500);
                        }
                    }, 5000);
                };
                
                img.src = imgElement.src;
            } else {
                throw new Error(`Could not find image element for background: ${selectedBackground}`);
            }
        } catch (error) {
            console.error('Error setting background:', error);
            // Fallback to a default gradient
            cardPreview.style.backgroundImage = 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)';
        }
    }
    
    // Update recipient/sender preview if those inputs exist
    updateTextPreviews();
}

// Helper function to update recipient/sender preview text
function updateTextPreviews() {
    const recipientInput = document.getElementById('recipient');
    const senderInput = document.getElementById('sender');
    const messageInput = document.getElementById('message');
    
    const previewRecipient = document.getElementById('preview-recipient-name');
    const previewSender = document.getElementById('preview-sender-name');
    const previewMessage = document.querySelector('.preview-message');
    
    if (recipientInput && previewRecipient) {
        previewRecipient.textContent = recipientInput.value || 'Friend';
    }
    
    if (senderInput && previewSender) {
        previewSender.textContent = senderInput.value || 'Me';
    }
    
    if (messageInput && previewMessage) {
        previewMessage.textContent = messageInput.value || 'Your personalized message will appear here. Try typing in the message box below!';
    }
}
