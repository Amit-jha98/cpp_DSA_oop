# Greeting Card Application

A web-based application for creating, customizing, and sharing digital greeting cards for various occasions.

## Features

- Create personalized greeting cards with custom messages
- Choose from predefined background themes or upload your own images
- Apply gradient backgrounds with customizable colors
- Select from various color schemes to match the card's mood
- Download cards as high-quality images
- Adjust blur and transparency effects
- Support for text customization and emojis

## Installation


1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

## Getting Started

1. Start the application:
   ```
   python app.py
   ```

2. Open your web browser and navigate to:
   ```
   http://localhost:5000
   ```

## Project Modules

### Core Application (`app.py`)
The main Flask application file that handles routes, card generation, and image processing.

### Templates
- `index.html` - Home page
- `create_card.html` - Card creation interface
- `preview_card.html` - Card preview page
- `saved_cards.html` - List of saved cards

### Static Assets
- `/static/images/backgrounds/` - Background images for cards
- `/static/fonts/` - Font files for text rendering
- `/static/css/` - Stylesheet files
- `/static/js/` - JavaScript files for interactive features
- `/static/uploads/` - Directory for user-uploaded images

### Utilities (`utils.py`)
Helper functions for image processing, color manipulation, and gradient generation.

## Card Creation Process

1. Choose a background theme (predefined image or custom upload)
2. Select a color scheme
3. Enter recipient and sender information
4. Write your personalized message
5. Adjust visual effects like blur and transparency
6. Preview the card
7. Download as image or share

## Technologies Used

- **Flask**: Web framework for the application
- **Pillow (PIL)**: Image processing library for card generation
- **Flask-WTF**: Form handling and validation
- **HTML/CSS/JavaScript**: Frontend user interface
- **Bootstrap**: Responsive design components

## System Requirements

- Python 3.7+
- Modern web browser
- Internet connection (for downloading fonts if not present)
