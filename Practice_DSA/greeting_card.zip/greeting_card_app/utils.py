"""
Utility functions for the Greeting Card App
"""
import math
from PIL import Image, ImageDraw

def hex_to_rgb(hex_color):
    """Convert hex color string to RGB tuple"""
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def create_gradient_image(width, height, color1, color2, direction):
    """Create a gradient image with the specified colors and direction"""
    img = Image.new('RGB', (width, height), color='white')
    draw = ImageDraw.Draw(img)
    
    # Interpret gradient direction
    if direction == 'to right' or direction == '90deg':
        # Horizontal gradient (left to right)
        for x in range(width):
            r = int(color1[0] + (color2[0] - color1[0]) * x / width)
            g = int(color1[1] + (color2[1] - color1[1]) * x / width)
            b = int(color1[2] + (color2[2] - color1[2]) * x / width)
            draw.line([(x, 0), (x, height)], fill=(r, g, b))
            
    elif direction == 'to bottom' or direction == '180deg':
        # Vertical gradient (top to bottom)
        for y in range(height):
            r = int(color1[0] + (color2[0] - color1[0]) * y / height)
            g = int(color1[1] + (color2[1] - color1[1]) * y / height)
            b = int(color1[2] + (color2[2] - color1[2]) * y / height)
            draw.line([(0, y), (width, y)], fill=(r, g, b))
            
    elif direction == 'to right bottom' or direction == '135deg':
        # Diagonal gradient (top-left to bottom-right)
        diagonal_length = math.sqrt(width**2 + height**2)
        for y in range(height):
            for x in range(width):
                # Calculate position along diagonal
                diag_pos = (x + y) / (width + height)
                r = int(color1[0] + (color2[0] - color1[0]) * diag_pos)
                g = int(color1[1] + (color2[1] - color1[1]) * diag_pos)
                b = int(color1[2] + (color2[2] - color1[2]) * diag_pos)
                draw.point((x, y), fill=(r, g, b))
                
    elif direction == 'to left bottom' or direction == '225deg':
        # Diagonal gradient (top-right to bottom-left)
        for y in range(height):
            for x in range(width):
                # Calculate position along diagonal
                diag_pos = ((width - x) + y) / (width + height)
                r = int(color1[0] + (color2[0] - color1[0]) * diag_pos)
                g = int(color1[1] + (color2[1] - color1[1]) * diag_pos)
                b = int(color1[2] + (color2[2] - color1[2]) * diag_pos)
                draw.point((x, y), fill=(r, g, b))
    
    elif direction.startswith('circle at'):
        # Radial gradient
        center_x, center_y = width // 2, height // 2
        radius = max(width, height) // 2
        
        for y in range(height):
            for x in range(width):
                # Calculate distance from center (normalized)
                distance = math.sqrt((x - center_x)**2 + (y - center_y)**2) / radius
                distance = min(distance, 1.0)  # Cap at 1.0
                
                r = int(color1[0] + (color2[0] - color1[0]) * distance)
                g = int(color1[1] + (color2[1] - color1[1]) * distance)
                b = int(color1[2] + (color2[2] - color1[2]) * distance)
                draw.point((x, y), fill=(r, g, b))
                
    else:
        # Default: Horizontal gradient
        for x in range(width):
            r = int(color1[0] + (color2[0] - color1[0]) * x / width)
            g = int(color1[1] + (color2[1] - color1[1]) * x / width)
            b = int(color1[2] + (color2[2] - color1[2]) * x / width)
            draw.line([(x, 0), (x, height)], fill=(r, g, b))
    
    return img
