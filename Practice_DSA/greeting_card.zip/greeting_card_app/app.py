from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_file, send_from_directory
import os
from datetime import datetime
import uuid
from PIL import Image, ImageDraw, ImageFont
import io
import base64
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, TextAreaField, SelectField
from werkzeug.utils import secure_filename
import json
import math
from utils import hex_to_rgb, create_gradient_image
from pathlib import Path
import requests
import urllib.request
import re
import shutil

app = Flask(__name__)
app.secret_key = "your-secret-key"
app.config['UPLOAD_FOLDER'] = os.path.join('static', 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Temporary storage for cards (in a real app, use a database)
CARDS = {}

BACKGROUNDS = {
    'birthday': 'static/images/backgrounds/birthday.jpg',
    'anniversary': 'static/images/backgrounds/anniversary.jpg',
    'thank_you': 'static/images/backgrounds/thank_you.jpg',
    'congratulations': 'static/images/backgrounds/congratulations.jpg',
    'holiday': 'static/images/backgrounds/holiday.jpg',
}

GRADIENT_BACKGROUNDS = {
    'gradient-sunset': {'color1': '#FF416C', 'color2': '#FF4B2B', 'direction': 'to right'},
    'gradient-ocean': {'color1': '#2E3192', 'color2': '#1BFFFF', 'direction': 'to right bottom'},
    'gradient-emerald': {'color1': '#43cea2', 'color2': '#185a9d', 'direction': '135deg'},
    'gradient-purple': {'color1': '#8E2DE2', 'color2': '#4A00E0', 'direction': 'to left'},
    'gradient-dawn': {'color1': '#F09819', 'color2': '#EDDE5D', 'direction': 'to bottom'},
    'gradient-cherry': {'color1': '#EB3349', 'color2': '#F45C43', 'direction': 'to top right'},
}

COLOR_SCHEMES = {
    'pastel': {'primary': '#F8B195', 'secondary': '#F67280', 'text': '#355C7D'},
    'vibrant': {'primary': '#A3A948', 'secondary': '#EDB92E', 'text': '#F85931'},
    'elegant': {'primary': '#DCDCDD', 'secondary': '#46494C', 'text': '#4C5C68'},
    'cheerful': {'primary': '#FDCB6E', 'secondary': '#E17055', 'text': '#2D3436'},
    'serene': {'primary': '#6FB3B8', 'secondary': '#BADFE7', 'text': '#388087'},
}

# Form for card creation
class CardForm(FlaskForm):
    recipient = StringField('To')
    sender = StringField('From')
    message = TextAreaField('Message')
    background = SelectField('Background Theme')
    color_scheme = SelectField('Color Scheme')
    font = SelectField('Font')
    custom_image = FileField('Custom Image', validators=[
        FileAllowed(['jpg', 'png', 'jpeg', 'gif'], 'Images only!')
    ])
    custom_gradient = StringField('Custom Gradient')
    blur_amount = StringField('Blur Amount')
    opacity = StringField('Opacity')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/uploads/<filename>')
def get_uploaded_image(filename):
    """Serve uploaded images securely"""
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/api/gradient/<gradient_id>')
def get_gradient_data(gradient_id):
    """Return gradient data as JSON"""
    if gradient_id in GRADIENT_BACKGROUNDS:
        return jsonify(GRADIENT_BACKGROUNDS[gradient_id])
    return jsonify({
        'color1': '#4e54c8',
        'color2': '#8f94fb',
        'direction': 'to right'
    })

@app.route('/create', methods=['GET', 'POST'])
def create_card():
    form = CardForm()
    
    if request.method == 'GET':
        return render_template('create_card.html', 
                              backgrounds=BACKGROUNDS,
                              gradient_backgrounds=GRADIENT_BACKGROUNDS,
                              color_schemes=COLOR_SCHEMES)
    
    # Process form submission
    if request.method == 'POST':
        card_id = str(uuid.uuid4())
        
        # Basic card data
        card_data = {
            'recipient': request.form.get('recipient', ''),
            'sender': request.form.get('sender', ''),
            'message': request.form.get('message', ''),
            'background': request.form.get('background', 'birthday'),
            'color_scheme': request.form.get('color_scheme', 'pastel'),
            'font': request.form.get('font', 'default'),
            'created_at': datetime.now(),
            'blur_amount': int(request.form.get('blur_amount', '3')),
            'opacity': int(request.form.get('opacity', '85')),
        }
        
        # Handle custom gradient
        if card_data['background'] == 'custom-gradient':
            custom_gradient_data = request.form.get('custom_gradient', '')
            try:
                gradient = json.loads(custom_gradient_data)
                card_data['gradient'] = {
                    'color1': gradient.get('color1', '#4e54c8'),
                    'color2': gradient.get('color2', '#8f94fb'),
                    'direction': gradient.get('direction', 'to right')
                }
            except:
                card_data['gradient'] = {
                    'color1': '#4e54c8', 
                    'color2': '#8f94fb', 
                    'direction': 'to right'
                }
        
        # Handle custom image upload
        if card_data['background'] == 'custom-image' and 'custom_image' in request.files:
            file = request.files['custom_image']
            if file and file.filename:
                # Create uploads directory if it doesn't exist
                os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
                
                # Save with a unique filename
                filename = secure_filename(f"{card_id}_{file.filename}")
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                
                # Store the relative path for the database/template
                card_data['custom_image_path'] = f"uploads/{filename}"
        
        CARDS[card_id] = card_data
        flash('Card created successfully!', 'success')
        return redirect(url_for('preview_card', card_id=card_id))

@app.route('/preview/<card_id>')
def preview_card(card_id):
    card = CARDS.get(card_id)
    if not card:
        flash('Card not found', 'error')
        return redirect(url_for('index'))
    
    return render_template('preview_card.html', card=card, card_id=card_id)

@app.route('/saved')
def saved_cards():
    # In a real app, filter cards by user
    user_cards = CARDS
    return render_template('saved_cards.html', cards=user_cards)

# Add API routes for advanced effects

@app.route('/api/preview', methods=['POST'])
def api_preview():
    """Generate HTML preview for real-time card updates"""
    try:
        # Get form data
        recipient = request.form.get('recipient', 'Friend')
        sender = request.form.get('sender', 'Me')
        message = request.form.get('message', 'Your message here...')
        background = request.form.get('background', 'birthday')
        color_scheme = request.form.get('color_scheme', 'pastel')
        font = request.form.get('font', 'default')
        
        # Get text effects if present
        text_effects = {}
        if 'text_effects' in request.form:
            try:
                text_effects = json.loads(request.form.get('text_effects', '{}'))
            except:
                pass
        
        # Get background style
        bg_style = ""
        if background.startswith('gradient-'):
            # Get gradient data
            if background in GRADIENT_BACKGROUNDS:
                gradient = GRADIENT_BACKGROUNDS[background]
                bg_style = f"background-image: linear-gradient({gradient['direction']}, {gradient['color1']}, {gradient['color2']});"
        elif background == 'custom-gradient':
            # Parse custom gradient
            try:
                custom_gradient = json.loads(request.form.get('custom_gradient', '{}'))
                color1 = custom_gradient.get('color1', '#4e54c8')
                color2 = custom_gradient.get('color2', '#8f94fb')
                direction = custom_gradient.get('direction', 'to right')
                bg_style = f"background-image: linear-gradient({direction}, {color1}, {color2});"
            except:
                bg_style = "background-image: linear-gradient(to right, #4e54c8, #8f94fb);"
        elif background == 'custom-image' and 'custom_image' in request.files:
            # We can't show a real-time preview of an uploaded file in this API
            bg_style = "background-color: #f8f9fa;"
        else:
            # Standard background
            bg_style = f"background-image: url('{url_for('static', filename='images/backgrounds/' + background + '.jpg')}');"
        
        # Create text style
        text_style = ""
        if text_effects.get('shadow', False):
            text_style += "text-shadow: 2px 2px 4px rgba(0,0,0,0.3);"
        if text_effects.get('glow', False):
            text_style += "text-shadow: 0 0 10px rgba(255,255,255,0.8), 0 0 20px rgba(255,255,255,0.5);"
        if 'spacing' in text_effects:
            text_style += f"letter-spacing: {text_effects['spacing']}px;"
        
        # Generate preview HTML
        blur_amount = request.form.get('blur_amount', '3')
        opacity = request.form.get('opacity', '85')
        opacity_float = int(opacity) / 100
        
        preview_html = f"""
        <div class="greeting-card" style="{bg_style}">
            <div class="greeting-card-inner" style="backdrop-filter: blur({blur_amount}px); background-color: rgba(255, 255, 255, {opacity_float});">
                <div class="greeting-content font-{font}" style="{text_style}">
                    <div class="recipient">Dear {recipient},</div>
                    <div class="message">{message}</div>
                    <div class="sender">With love,<br>{sender}</div>
                </div>
            </div>
        </div>
        """
        
        return jsonify({'previewHtml': preview_html})
    except Exception as e:
        print(f"Error generating preview: {e}")
        return jsonify({'error': 'Failed to generate preview'}), 500

@app.route('/api/enhance-image', methods=['POST'])
def api_enhance_image():
    """Process and enhance uploaded images"""
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image provided'}), 400
            
        image_file = request.files['image']
        if not image_file or not image_file.filename:
            return jsonify({'error': 'Invalid image file'}), 400
            
        # Get enhancement parameters
        brightness = float(request.form.get('brightness', '0'))
        contrast = float(request.form.get('contrast', '0'))
        saturation = float(request.form.get('saturation', '0'))
        sharpness = float(request.form.get('sharpness', '0'))
        
        # Process image with Pillow
        img = Image.open(image_file)
        
        # Apply enhancements
        if brightness != 0:
            from PIL import ImageEnhance
            factor = 1.0 + brightness / 100.0
            enhancer = ImageEnhance.Brightness(img)
            img = enhancer.enhance(factor)
            
        if contrast != 0:
            from PIL import ImageEnhance
            factor = 1.0 + contrast / 100.0
            enhancer = ImageEnhance.Contrast(img)
            img = enhancer.enhance(factor)
            
        if saturation != 0:
            from PIL import ImageEnhance
            factor = 1.0 + saturation / 100.0
            enhancer = ImageEnhance.Color(img)
            img = enhancer.enhance(factor)
            
        if sharpness > 0:
            from PIL import ImageEnhance
            factor = 1.0 + sharpness / 100.0
            enhancer = ImageEnhance.Sharpness(img)
            img = enhancer.enhance(factor)
        
        # Save to memory and convert to base64 for response
        buffer = io.BytesIO()
        img.save(buffer, format="PNG")
        img_str = base64.b64encode(buffer.getvalue()).decode('utf-8')
        
        return jsonify({
            'enhancedImage': f"data:image/png;base64,{img_str}",
            'success': True
        })
    except Exception as e:
        print(f"Error enhancing image: {e}")
        return jsonify({'error': 'Image enhancement failed'}), 500

@app.route('/api/analyze-image-colors', methods=['POST'])
def api_analyze_image_colors():
    """Analyze image colors and suggest color schemes"""
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image provided'}), 400
            
        image_file = request.files['image']
        if not image_file or not image_file.filename:
            return jsonify({'error': 'Invalid image file'}), 400
        
        # Open and resize image for analysis (for performance)
        img = Image.open(image_file)
        img = img.resize((150, 150))
        
        # Convert to RGB if needed
        if img.mode != 'RGB':
            img = img.convert('RGB')
        
        # Get color palette (simple implementation - could be enhanced)
        pixels = list(img.getdata())
        color_counts = {}
        
        # Count colors (downsampled)
        for pixel in pixels[::10]:  # Sample every 10th pixel for performance
            # Quantize colors to reduce variations
            r = int(pixel[0] / 16) * 16
            g = int(pixel[1] / 16) * 16
            b = int(pixel[2] / 16) * 16
            quantized = (r, g, b)
            
            if quantized in color_counts:
                color_counts[quantized] += 1
            else:
                color_counts[quantized] = 1
        
        # Sort by frequency
        sorted_colors = sorted(color_counts.items(), key=lambda x: x[1], reverse=True)
        
        # Get top colors excluding near-white and near-black
        dominant_colors = []
        for color, count in sorted_colors[:15]:
            r, g, b = color
            # Skip near-white and near-black
            if (r + g + b > 720) or (r + g + b < 60):
                continue
                
            # Convert to hex
            hex_color = f"#{r:02x}{g:02x}{b:02x}"
            # Calculate percentage
            percentage = (count / len(pixels)) * 100
            
            dominant_colors.append({
                'hex': hex_color,
                'rgb': color,
                'percentage': percentage
            })
            
            # Stop after we've found 5 colors
            if len(dominant_colors) >= 5:
                break
        
        # If we couldn't find enough colors, add some default ones
        if len(dominant_colors) < 2:
            dominant_colors.append({'hex': '#4e54c8', 'rgb': (78, 84, 200), 'percentage': 50})
            dominant_colors.append({'hex': '#8f94fb', 'rgb': (143, 148, 251), 'percentage': 30})
        
        # Generate color schemes based on the dominant color
        main_color = dominant_colors[0]['hex']
        
        # Create some basic color schemes
        color_schemes = {
            'monochromatic': [
                main_color,
                lighten_darken_color(main_color, 40)
            ],
            'complementary': [
                main_color,
                complementary_color(main_color)
            ]
        }
        
        # Add a third scheme if we have enough colors
        if len(dominant_colors) >= 3:
            color_schemes['triadic'] = [
                dominant_colors[0]['hex'],
                dominant_colors[1]['hex'],
                dominant_colors[2]['hex']
            ]
        
        return jsonify({
            'dominantColors': dominant_colors,
            'suggestedSchemes': color_schemes,
            'success': True
        })
    except Exception as e:
        print(f"Error analyzing image colors: {e}")
        return jsonify({'error': 'Color analysis failed'}), 500

# Helper functions for color analysis
def lighten_darken_color(hex_color, amount):
    """Lighten or darken a hex color"""
    # Convert hex to rgb
    hex_color = hex_color.lstrip('#')
    r = int(hex_color[0:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:6], 16)
    
    # Adjust values
    r = max(0, min(255, r + amount))
    g = max(0, min(255, g + amount))
    b = max(0, min(255, b + amount))
    
    # Convert back to hex
    return f"#{r:02x}{g:02x}{b:02x}"

def complementary_color(hex_color):
    """Get the complementary color of a hex color"""
    # Convert hex to rgb
    hex_color = hex_color.lstrip('#')
    r = int(hex_color[0:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:6], 16)
    
    # Get complementary (invert each component)
    r = 255 - r
    g = 255 - g
    b = 255 - b
    
    # Convert back to hex
    return f"#{r:02x}{g:02x}{b:02x}"

# Add a function to ensure emoji-compatible fonts are available
def ensure_fonts_available():
    """Ensure that emoji-compatible fonts are available for the application"""
    fonts_dir = os.path.join('static', 'fonts')
    os.makedirs(fonts_dir, exist_ok=True)
    
    font_files = {
        'NotoSans-Regular.ttf': 'https://github.com/googlefonts/noto-fonts/raw/main/hinted/ttf/NotoSans/NotoSans-Regular.ttf',
        'NotoSansSymbols-Regular.ttf': 'https://github.com/googlefonts/noto-fonts/raw/main/hinted/ttf/NotoSansSymbols/NotoSansSymbols-Regular.ttf',
        'NotoEmoji-Regular.ttf': 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoEmoji-Regular.ttf',
        'NotoSerifDisplay-Regular.ttf': 'https://github.com/googlefonts/noto-fonts/raw/main/hinted/ttf/NotoSerifDisplay/NotoSerifDisplay-Regular.ttf',
        'Pacifico-Regular.ttf': 'https://github.com/google/fonts/raw/main/ofl/pacifico/Pacifico-Regular.ttf',
        'Oswald-Bold.ttf': 'https://github.com/google/fonts/raw/main/ofl/oswald/Oswald-Bold.ttf'
    }
    
    # Check and download fonts if needed
    for font_name, font_url in font_files.items():
        font_path = os.path.join(fonts_dir, font_name)
        if not os.path.exists(font_path):
            try:
                print(f"Downloading font: {font_name}")
                urllib.request.urlretrieve(font_url, font_path)
                print(f"Downloaded {font_name} successfully")
            except Exception as e:
                print(f"Error downloading font {font_name}: {e}")

# Update the download_card function to properly handle fonts and emojis
@app.route('/download/<card_id>')
def download_card(card_id):
    """Generate and download a greeting card as an image with proper fonts and emoji support"""
    card = CARDS.get(card_id)
    if not card:
        flash('Card not found', 'error')
        return redirect(url_for('index'))
    
    # Get requested format and quality
    img_format = request.args.get('format', 'jpg').lower()
    quality = request.args.get('quality', 'high')
    
    # Ensure fonts are available
    ensure_fonts_available()
    
    try:
        # Set dimensions based on quality
        if quality == 'high':
            width, height = 1600, 1200
        else:
            width, height = 1000, 750
            
        # Create base image - either from gradient, custom image, or background
        card_img = create_base_image(card, width, height)
        
        # Apply overlay with blur effect
        card_img = apply_overlay_with_blur(card_img, card.get('opacity', 85), card.get('blur_amount', 3))
        
        # Get font paths for different styles
        fonts = get_font_paths(card['font'])
        
        # Calculate font sizes that scale properly with image dimensions
        font_sizes = calculate_font_sizes(width, height, quality)
        
        # Prepare drawing context
        draw = ImageDraw.Draw(card_img)
        
        # Get text color based on color scheme
        text_color = get_text_color(card['color_scheme'])
        
        # Draw the card content with proper emoji support
        draw_card_content(draw, card, width, height, fonts, font_sizes, text_color)
        
        # Save the image to memory
        img_io = save_image_to_memory(card_img, card, img_format, quality, card_id)
        
        # Return the downloadable file
        return send_file(
            img_io, 
            mimetype=get_mimetype(img_format),
            download_name=generate_filename(card, card_id, img_format),
            as_attachment=True
        )
    
    except Exception as e:
        print(f"Error generating card: {e}")
        import traceback
        traceback.print_exc()
        flash(f"There was an error generating your card. Please try again.", 'error')
        return redirect(url_for('preview_card', card_id=card_id))

def create_base_image(card, width, height):
    """Create the base image based on background type"""
    if card['background'].startswith('gradient-') or card['background'] == 'custom-gradient':
        # Handle gradient backgrounds
        if card['background'] == 'custom-gradient' and 'gradient' in card:
            gradient_data = card['gradient']
        elif card['background'] in GRADIENT_BACKGROUNDS:
            gradient_data = GRADIENT_BACKGROUNDS[card['background']]
        else:
            gradient_data = {'color1': '#4e54c8', 'color2': '#8f94fb', 'direction': 'to right'}
        
        color1 = hex_to_rgb(gradient_data['color1'])
        color2 = hex_to_rgb(gradient_data['color2'])
        return create_gradient_image(width, height, color1, color2, gradient_data['direction'])
        
    elif card['background'] == 'custom-image' and 'custom_image_path' in card:
        # Handle custom uploaded image
        try:
            image_path = os.path.join('static', card['custom_image_path'])
            if os.path.exists(image_path):
                bg_img = Image.open(image_path).convert('RGBA')
                bg_img = bg_img.resize((width, height), Image.LANCZOS)
                
                # Create a new RGB image and paste the background
                img = Image.new('RGB', (width, height), color='white')
                img.paste(bg_img, (0, 0), bg_img if bg_img.mode == 'RGBA' else None)
                return img
            else:
                raise FileNotFoundError(f"Custom image not found: {image_path}")
        except Exception as e:
            print(f"Error loading custom image: {e}")
            # Fall back to white
            return Image.new('RGB', (width, height), color='white')
    else:
        # Handle regular background image
        try:
            bg_path = os.path.join('static', 'images', 'backgrounds', f"{card['background']}.jpg")
            if os.path.exists(bg_path):
                bg_img = Image.open(bg_path).convert('RGB')
                bg_img = bg_img.resize((width, height), Image.LANCZOS)
                return bg_img
            else:
                raise FileNotFoundError(f"Background image not found: {bg_path}")
        except Exception as e:
            print(f"Error loading background: {e}")
            # Fall back to white
            return Image.new('RGB', (width, height), color='white')

def apply_overlay_with_blur(img, opacity_percent, blur_amount):
    """Apply semi-transparent overlay with optional blur effect"""
    try:
        # Convert percentage to 0-255 alpha value
        opacity_value = int(255 * (opacity_percent / 100))
        
        # Apply blur if requested
        if blur_amount > 0:
            try:
                from PIL import ImageFilter
                img = img.filter(ImageFilter.GaussianBlur(radius=blur_amount))
            except Exception as e:
                print(f"Error applying blur: {e}")
        
        # Create overlay and composite
        overlay = Image.new('RGBA', img.size, (255, 255, 255, opacity_value))
        
        # Ensure image is in RGBA mode for compositing
        img_rgba = img.convert('RGBA')
        result = Image.alpha_composite(img_rgba, overlay)
        
        return result
    except Exception as e:
        print(f"Error applying overlay: {e}")
        return img

def get_font_paths(font_style):
    """Get font paths for different components with emoji support"""
    fonts_dir = os.path.join('static', 'fonts')
    
    # Base fonts with emoji support
    noto_regular = os.path.join(fonts_dir, 'NotoSans-Regular.ttf')
    noto_emoji = os.path.join(fonts_dir, 'NotoEmoji-Regular.ttf')
    
    # Style-specific fonts
    if font_style == 'elegant':
        primary_font = os.path.join(fonts_dir, 'NotoSerifDisplay-Regular.ttf')
    elif font_style == 'playful':
        primary_font = os.path.join(fonts_dir, 'Pacifico-Regular.ttf')
    elif font_style == 'bold':
        primary_font = os.path.join(fonts_dir, 'Oswald-Bold.ttf')
    else:  # default
        primary_font = noto_regular
    
    # Fallback if the primary font doesn't exist
    if not os.path.exists(primary_font):
        primary_font = noto_regular
    
    return {
        'primary': primary_font,
        'emoji': noto_emoji if os.path.exists(noto_emoji) else primary_font
    }

def calculate_font_sizes(width, height, quality):
    """Calculate proportional font sizes based on image dimensions"""
    # Base sizes for 1000x750
    base_width = 1000
    multiplier = width / base_width
    
    return {
        'title': int(36 * multiplier),
        'message': int(24 * multiplier),
        'signature': int(26 * multiplier),
        'watermark': int(14 * multiplier)
    }

def get_text_color(color_scheme):
    """Get RGB color tuple based on color scheme"""
    color_map = {
        'pastel': (53, 92, 125),       # #355C7D
        'vibrant': (248, 89, 49),      # #F85931
        'elegant': (76, 92, 104),      # #4C5C68
        'cheerful': (45, 52, 54),      # #2D3436
        'serene': (56, 128, 135),      # #388087
    }
    return color_map.get(color_scheme, (0, 0, 0))

def draw_card_content(draw, card, width, height, fonts, font_sizes, text_color):
    """Draw the card content with proper emoji support"""
    # Load fonts for different parts
    try:
        font_title = ImageFont.truetype(fonts['primary'], font_sizes['title'])
        font_message = ImageFont.truetype(fonts['primary'], font_sizes['message'])
        font_signature = ImageFont.truetype(fonts['primary'], font_sizes['signature'])
        font_watermark = ImageFont.truetype(fonts['primary'], font_sizes['watermark'])
    except Exception as e:
        print(f"Error loading fonts: {e}")
        # Fallback to default
        font_title = ImageFont.load_default()
        font_message = ImageFont.load_default()
        font_signature = ImageFont.load_default()
        font_watermark = ImageFont.load_default()
    
    # 1. Draw recipient
    recipient_text = f"Dear {card['recipient']},"
    draw_text_with_emoji(draw, recipient_text, width/2, height*0.15, font_title, text_color, 'center', fonts['emoji'])
    
    # 2. Draw message with word wrapping and emoji support
    message_lines = wrap_text_with_emojis(draw, card['message'], font_message, width*0.75)
    
    # Calculate message block height to center it
    message_height = len(message_lines) * (font_sizes['message'] * 1.5)
    message_start_y = (height - message_height) / 2
    
    for i, line in enumerate(message_lines):
        y_pos = message_start_y + i * (font_sizes['message'] * 1.5)
        draw_text_with_emoji(draw, line, width/2, y_pos, font_message, text_color, 'center', fonts['emoji'])
    
    # 3. Draw signature
    signature_y = height * 0.8
    draw_text_with_emoji(draw, "With love,", width/2, signature_y, font_signature, text_color, 'center', fonts['emoji'])
    draw_text_with_emoji(draw, card['sender'], width/2, signature_y + (font_sizes['signature'] * 1.5), 
                        font_signature, text_color, 'center', fonts['emoji'])
    
    # 4. Draw watermark
    watermark_text = f"Card #{card.get('id', '')[:8]}"
    draw_text_with_emoji(draw, watermark_text, width - 20, height - 20, 
                        font_watermark, text_color, 'right', fonts['emoji'])

def draw_text_with_emoji(draw, text, x, y, font, color, align='left', emoji_font=None):
    """Draw text with emoji support using fallback font for emojis if needed"""
    # Get text dimensions for positioning
    left, top, right, bottom = draw.textbbox((0, 0), text, font=font)
    text_width = right - left
    text_height = bottom - top
    
    # Calculate position based on alignment
    if align == 'center':
        position = (x - text_width/2, y - text_height/2)
    elif align == 'right':
        position = (x - text_width, y - text_height)
    else:  # left
        position = (x, y)
    
    # Draw the text
    draw.text(position, text, fill=color, font=font)

def wrap_text_with_emojis(draw, text, font, max_width):
    """Wrap text to fit within max_width, preserving emojis"""
    words = text.split()
    lines = []
    current_line = []
    
    for word in words:
        test_line = ' '.join(current_line + [word])
        left, top, right, bottom = draw.textbbox((0, 0), test_line, font=font)
        test_width = right - left
        
        if test_width <= max_width:
            current_line.append(word)
        else:
            if current_line:
                lines.append(' '.join(current_line))
                current_line = [word]
            else:
                # If a single word is too long to fit, force it onto a line
                lines.append(word)
                current_line = []
    
    if current_line:
        lines.append(' '.join(current_line))
    
    return lines

def save_image_to_memory(img, card, img_format, quality, card_id):
    """Save the image to memory in the requested format"""
    img_io = io.BytesIO()
    
    # Convert back to RGB mode if needed
    if img.mode == 'RGBA' and img_format in ['jpg', 'jpeg']:
        img = img.convert('RGB')
    
    # Save with appropriate format and quality
    if img_format in ['jpg', 'jpeg']:
        quality_value = 95 if quality == 'high' else 85
        img.save(img_io, format='JPEG', quality=quality_value)
    elif img_format == 'png':
        compression = 0 if quality == 'high' else 3
        img.save(img_io, format='PNG', compress_level=compression)
    else:
        # Default to JPEG
        img.save(img_io, format='JPEG', quality=95)
    
    img_io.seek(0)
    return img_io

def get_mimetype(img_format):
    """Get the appropriate mimetype for the image format"""
    format_mimetypes = {
        'jpg': 'image/jpeg',
        'jpeg': 'image/jpeg',
        'png': 'image/png',
        'pdf': 'application/pdf',
    }
    return format_mimetypes.get(img_format, 'image/jpeg')

def generate_filename(card, card_id, img_format):
    """Generate a user-friendly filename for the download"""
    card_type = card['background'].replace('_', '-')
    recipient_name = card['recipient'].replace(' ', '-')
    
    # Clean up the recipient name to ensure valid filename
    recipient_name = re.sub(r'[^\w\-]', '', recipient_name)
    
    return f"greeting-card-{card_id[:8]}-for-{recipient_name}.{img_format}"

# Add this function to handle missing images and update the startup code

def ensure_background_images_exist():
    """Ensure that all required background images exist"""
    for bg_name in BACKGROUNDS:
        bg_path = os.path.join('static', 'images', 'backgrounds', f"{bg_name}.jpg")
        if not os.path.exists(bg_path):
            print(f"Warning: Background image {bg_path} is missing")
            
            # Create backgrounds directory if it doesn't exist
            backgrounds_dir = os.path.dirname(bg_path)
            os.makedirs(backgrounds_dir, exist_ok=True)
            
            try:
                # Try to download missing images
                print(f"Attempting to download missing image {bg_name}.jpg...")
                try:
                    # Import the download utility and run it
                    from download_sample_images import SAMPLE_IMAGES
                    
                    if bg_name in SAMPLE_IMAGES:
                        url = SAMPLE_IMAGES[bg_name]
                        import urllib.request
                        import ssl
                        ssl_context = ssl._create_unverified_context()
                        urllib.request.urlretrieve(url, bg_path, context=ssl_context)
                        print(f"Downloaded {bg_name}.jpg successfully")
                    else:
                        raise ValueError(f"No sample URL for {bg_name}")
                except Exception as e:
                    print(f"Failed to download: {e}")
                    
                    # Create a fallback image with gradient
                    create_fallback_image(bg_path, bg_name)
            except Exception as e:
                print(f"Error ensuring background image exists: {e}")

def create_fallback_image(file_path, name):
    """Create a fallback background image with gradient"""
    try:
        # Create a 800x600 image with gradient
        img = Image.new('RGB', (800, 600), color='white')
        draw = ImageDraw.Draw(img)
        
        # Draw a simple gradient based on image name for variety
        name_hash = sum(ord(c) for c in name) % 360
        
        for y in range(600):
            # Create a gradient based on name_hash
            r = int(100 + (y/600) * 100 + name_hash % 55)
            g = int(100 + (y/600) * 100 + (name_hash + 120) % 55)
            b = int(100 + (y/600) * 100 + (name_hash + 240) % 55)
            
            # Keep values in valid range
            r = min(255, max(0, r))
            g = min(255, max(0, g))
            b = min(255, max(0, b))
            
            draw.line([(0, y), (800, y)], fill=(r, g, b))
        
        # Add text
        try:
            # Try to find a system font
            font_paths = [
                "arial.ttf",  # Windows
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",  # Linux
                "/System/Library/Fonts/Helvetica.ttc"  # macOS
            ]
            
            font = None
            for font_path in font_paths:
                try:
                    font = ImageFont.truetype(font_path, 40)
                    break
                except:
                    continue
                    
            if font is None:
                font = ImageFont.load_default()
        except:
            font = ImageFont.load_default()
        
        # Draw image name as text
        title = name.replace('_', ' ').title()
        text_bbox = draw.textbbox((0, 0), title, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]
        text_x = (800 - text_width) // 2
        text_y = (600 - text_height) // 2
        
        # Draw text with shadow for better visibility
        draw.text((text_x + 2, text_y + 2), title, fill="black", font=font)
        draw.text((text_x, text_y), title, fill="white", font=font)
        
        # Save the image
        img.save(file_path)
        print(f"Created fallback image for {name}")
    except Exception as e:
        print(f"Failed to create fallback image: {e}")

# Update the main block to include image checks
if __name__ == '__main__':
    try:
        # Create sample background images directory if it doesn't exist
        os.makedirs('static/images/backgrounds', exist_ok=True)
        
        # Ensure all required background images exist
        ensure_background_images_exist()
        
        # Ensure we have fonts for text and emojis
        ensure_fonts_available()
        
        # Print startup message
        print("\n" + "="*50)
        print(" Greeting Card App Server Starting")
        print("="*50)
        print(" * Open your browser and go to: http://localhost:5000")
        print("="*50 + "\n")
        
        # Run the Flask app with debug mode enabled and increased timeout
        app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0  # Disable caching for development
        app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload
        app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)
    except Exception as e:
        print(f"ERROR: Failed to start the server: {e}")
        import traceback
        traceback.print_exc()