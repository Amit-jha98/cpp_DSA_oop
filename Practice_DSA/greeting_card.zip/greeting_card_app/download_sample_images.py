"""
Utility script to download sample background images for the greeting card app
"""
import os
import urllib.request
import ssl

# Sample images to download if they are missing
SAMPLE_IMAGES = {
    'birthday': 'https://images.unsplash.com/photo-1513151233558-d860c5398176?w=800&q=80',
    'anniversary': 'https://images.unsplash.com/photo-1522057306606-8d84b31a9671?w=800&q=80',
    'thank_you': 'https://images.unsplash.com/photo-1536064479547-8c39aad20140?w=800&q=80',
    'congratulations': 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=800&q=80',
    'holiday': 'https://images.unsplash.com/photo-1482330454287-3cf6611d0bc9?w=800&q=80',
}

def download_sample_images():
    """Download sample images for background templates"""
    # Create backgrounds directory if it doesn't exist
    backgrounds_dir = os.path.join('static', 'images', 'backgrounds')
    os.makedirs(backgrounds_dir, exist_ok=True)
    
    # Allow unverified HTTPS requests (for sample download only)
    ssl_context = ssl._create_unverified_context()
    
    # Download missing images
    for name, url in SAMPLE_IMAGES.items():
        file_path = os.path.join(backgrounds_dir, f"{name}.jpg")
        
        if not os.path.exists(file_path):
            print(f"Downloading {name}.jpg...")
            try:
                urllib.request.urlretrieve(url, file_path, context=ssl_context)
                print(f"Downloaded {name}.jpg successfully")
            except Exception as e:
                print(f"Failed to download {name}.jpg: {e}")
                
                # Create a fallback image with gradient
                try:
                    from PIL import Image, ImageDraw
                    
                    # Create a 800x600 image with gradient
                    img = Image.new('RGB', (800, 600), color='white')
                    draw = ImageDraw.Draw(img)
                    
                    # Draw a simple gradient as fallback
                    for y in range(600):
                        # Create a blue-to-purple gradient
                        r = int(83 + (y/600) * 72)
                        g = int(84 + (y/600) * 64)
                        b = int(200 - (y/600) * 0)
                        
                        draw.line([(0, y), (800, y)], fill=(r, g, b))
                    
                    # Add text
                    from PIL import ImageFont
                    try:
                        # Try to use a system font
                        font = ImageFont.truetype("arial.ttf", 40)
                    except:
                        # Fallback to default
                        font = ImageFont.load_default()
                    
                    # Draw image name as text
                    title = name.replace('_', ' ').title()
                    draw.text((400, 300), title, fill="white", font=font, anchor="mm")
                    
                    # Save the image
                    img.save(file_path)
                    print(f"Created fallback image for {name}.jpg")
                except Exception as inner_e:
                    print(f"Failed to create fallback image: {inner_e}")
        else:
            print(f"{name}.jpg already exists")

if __name__ == "__main__":
    download_sample_images()
