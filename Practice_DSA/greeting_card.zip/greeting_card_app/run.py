import os
import sys
import subprocess
import webbrowser
import time

def check_dependencies():
    """Check if all required packages are installed"""
    required = ['flask', 'pillow', 'flask_wtf']  # Added flask_wtf for form handling
    missing = []
    
    for package in required:
        try:
            __import__(package)
        except ImportError:
            missing.append(package)
    
    return missing

def main():
    """Run the application with proper error handling"""
    print("Checking dependencies...")
    missing = check_dependencies()
    
    if missing:
        print(f"Missing dependencies: {', '.join(missing)}")
        install = input("Would you like to install them now? (y/n): ")
        
        if install.lower() == 'y':
            print("Installing dependencies...")
            subprocess.call([sys.executable, "-m", "pip", "install"] + missing)
        else:
            print("Cannot start application without required dependencies.")
            return
    
    print("Starting Greeting Card application...")
    
    # Ensure the app directory has required folders
    os.makedirs('static/images/backgrounds', exist_ok=True)
    
    # Check if there are sample backgrounds
    bg_dir = 'static/images/backgrounds'
    if not os.listdir(bg_dir) or len(os.listdir(bg_dir)) < 2:
        print("Adding sample background images...")
        # This would be where you'd add logic to create sample backgrounds if needed
    
    # Start the Flask application
    try:
        # Open browser after a short delay
        def open_browser():
            time.sleep(1.5)
            webbrowser.open('http://localhost:5000')
        
        import threading
        threading.Timer(1, open_browser).start()
        
        # Start the Flask app
        os.environ['FLASK_ENV'] = 'development'
        os.environ['FLASK_DEBUG'] = '1'
        subprocess.call([sys.executable, "app.py"])
    except Exception as e:
        print(f"Failed to start the application: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
