import os
from PIL import Image, ImageDraw
import random

def generate_sample_background(name, width, height, output_dir):
    """Generate a sample background image with the given name"""
    img = Image.new('RGB', (width, height), color='white')
    draw = ImageDraw.Draw(img)
    
    # Different patterns based on name
    if name == 'birthday':
        # Birthday pattern with confetti
        for _ in range(500):
            x = random.randint(0, width)
            y = random.randint(0, height)
            size = random.randint(2, 8)
            color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
            draw.ellipse((x, y, x+size, y+size), fill=color)
    
    elif name == 'anniversary':
        # Anniversary pattern with hearts
        for _ in range(100):
            x = random.randint(0, width-50)
            y = random.randint(0, height-50)
            size = random.randint(10, 40)
            color = (random.randint(150, 255), random.randint(0, 100), random.randint(0, 100))
            # Simple heart shape
            draw.ellipse((x, y, x+size, y+size), fill=color)
            draw.ellipse((x+size, y, x+2*size, y+size), fill=color)
            draw.polygon([(x+size//2, y+size*1.5), (x+3*size//2, y+size*1.5), (x+size, y+size//2)], fill=color)
    
    elif name == 'thank_you':
        # Thank You pattern with soft squares
        for _ in range(50):
            x = random.randint(0, width)
            y = random.randint(0, height)
            size = random.randint(20, 100)
            color = (random.randint(100, 200), random.randint(150, 255), random.randint(150, 255))
            draw.rectangle((x, y, x+size, y+size), fill=color, outline=None)
    
    elif name == 'congratulations':
        # Congratulations pattern with stars
        for _ in range(80):
            x = random.randint(0, width)
            y = random.randint(0, height)
            size = random.randint(10, 50)
            color = (random.randint(200, 255), random.randint(200, 255), random.randint(0, 100))
            
            # Simple star shape
            points = []
            for i in range(5):
                points.append((x + size*0.5*0.5 * (0.5 + i) % 5, y + size*0.5*0.5 * (0.5 + i*2) % 5))
                points.append((x + size*0.5, y + size*0.5))
            draw.polygon(points, fill=color)
    
    elif name == 'holiday':
        # Holiday pattern with snow
        for _ in range(300):
            x = random.randint(0, width)
            y = random.randint(0, height)
            size = random.randint(2, 8)
            color = (255, 255, 255, random.randint(100, 255))
            draw.ellipse((x, y, x+size, y+size), fill=color)
        
        # Add some green and red accents
        for _ in range(50):
            x = random.randint(0, width)
            y = random.randint(0, height)
            size = random.randint(10, 30)
            color = (random.randint(0, 50), random.randint(100, 200), random.randint(0, 50)) if random.random() > 0.5 else (random.randint(200, 255), random.randint(0, 50), random.randint(0, 50))
            draw.ellipse((x, y, x+size, y+size), fill=color)
    
    else:
        # Default pattern with gradient
        for y in range(height):
            r = int(255 * y / height)
            g = int(200 - 150 * y / height)
            b = int(255 - 255 * y / height)
            for x in range(width):
                draw.point((x, y), fill=(r, g, b))
    
    # Save the image
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, f"{name}.jpg")
    img.save(output_path, 'JPEG', quality=95)
    print(f"Generated background: {output_path}")

def main():
    # Create backgrounds
    background_dir = os.path.join('static', 'images', 'backgrounds')
    backgrounds = ['birthday', 'anniversary', 'thank_you', 'congratulations', 'holiday']
    
    print("Generating sample backgrounds...")
    for bg in backgrounds:
        generate_sample_background(bg, 800, 600, background_dir)
    
    print("Done! Sample backgrounds are ready to use.")

if __name__ == "__main__":
    main()
